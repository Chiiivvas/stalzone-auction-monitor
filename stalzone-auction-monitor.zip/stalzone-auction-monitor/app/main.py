from __future__ import annotations

import argparse
import logging
import time

from .config import load_settings
from .database.db import Database
from .logging_setup import setup_logging
from .monitoring.monitor import Monitor
from .monitoring.runner import MonitorRunner, build_notifiers

log = logging.getLogger(__name__)


def main() -> int:
    parser = argparse.ArgumentParser(description="STALZONE Auction Monitor (RU)")
    parser.add_argument("--headless", action="store_true", help="run without GUI (console only)")
    args = parser.parse_args()

    settings = load_settings()
    setup_logging(settings.log_dir)
    db = Database(settings.db_path)
    monitor = Monitor(db, build_notifiers(settings))
    runner = MonitorRunner(settings, monitor)

    if args.headless:
        if not settings.api_token:
            log.error("STALZONE_API_TOKEN is not set (see .env.example)")
            return 1
        log.info("Watching %d items", len(db.list_rules(enabled_only=True)))
        runner.start()
        try:
            while runner.running:
                time.sleep(0.5)
        except KeyboardInterrupt:
            runner.stop()
        return 0

    from .ui.main_window import run_gui   # imported lazily: tkinter not needed for headless
    run_gui(settings, db, monitor, runner)
    return 0
