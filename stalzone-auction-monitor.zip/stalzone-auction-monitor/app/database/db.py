"""SQLite storage (stdlib sqlite3): rules, settings, detected lots / dedup state."""
from __future__ import annotations

import sqlite3
import threading
from datetime import datetime, timedelta, timezone
from pathlib import Path

from ..auction.models import WatchRule

SCHEMA = """
CREATE TABLE IF NOT EXISTS watch_rules (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    item_id TEXT NOT NULL,
    name TEXT NOT NULL,
    max_unit_price INTEGER NOT NULL CHECK (max_unit_price >= 0),
    min_amount INTEGER NOT NULL DEFAULT 1 CHECK (min_amount >= 1),
    max_lot_price INTEGER,
    enabled INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS app_settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS detected_lots (
    fingerprint TEXT PRIMARY KEY,
    rule_id INTEGER,
    item_id TEXT NOT NULL,
    item_name TEXT NOT NULL,
    amount INTEGER NOT NULL,
    buyout_price INTEGER NOT NULL,
    unit_price REAL NOT NULL,
    price_limit INTEGER NOT NULL,
    end_time TEXT,
    first_seen TEXT NOT NULL,
    notified INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_detected_first_seen ON detected_lots(first_seen);
"""


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


class Database:
    def __init__(self, path: str = "data/monitor.db") -> None:
        if path != ":memory:":
            Path(path).parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(path, check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._lock = threading.RLock()
        with self._lock:
            self._conn.executescript(SCHEMA)

    def close(self) -> None:
        with self._lock:
            self._conn.close()

    # ---- rules -------------------------------------------------------
    @staticmethod
    def _rule(row: sqlite3.Row) -> WatchRule:
        return WatchRule(id=row["id"], item_id=row["item_id"], name=row["name"],
                         max_unit_price=row["max_unit_price"], min_amount=row["min_amount"],
                         max_lot_price=row["max_lot_price"], enabled=bool(row["enabled"]))

    def list_rules(self, enabled_only: bool = False) -> list[WatchRule]:
        sql = "SELECT * FROM watch_rules" + (" WHERE enabled = 1" if enabled_only else "") + " ORDER BY id"
        with self._lock:
            return [self._rule(r) for r in self._conn.execute(sql)]

    def add_rule(self, rule: WatchRule) -> int:
        with self._lock, self._conn:
            cur = self._conn.execute(
                "INSERT INTO watch_rules (item_id, name, max_unit_price, min_amount, max_lot_price, enabled)"
                " VALUES (?,?,?,?,?,?)",
                (rule.item_id, rule.name, rule.max_unit_price, rule.min_amount,
                 rule.max_lot_price, int(rule.enabled)))
            return int(cur.lastrowid)

    def update_rule(self, rule: WatchRule) -> None:
        with self._lock, self._conn:
            self._conn.execute(
                "UPDATE watch_rules SET item_id=?, name=?, max_unit_price=?, min_amount=?,"
                " max_lot_price=?, enabled=? WHERE id=?",
                (rule.item_id, rule.name, rule.max_unit_price, rule.min_amount,
                 rule.max_lot_price, int(rule.enabled), rule.id))

    def delete_rule(self, rule_id: int) -> None:
        with self._lock, self._conn:
            self._conn.execute("DELETE FROM watch_rules WHERE id=?", (rule_id,))

    # ---- settings ----------------------------------------------------
    def get_setting(self, key: str, default: str) -> str:
        with self._lock:
            row = self._conn.execute("SELECT value FROM app_settings WHERE key=?", (key,)).fetchone()
        return row["value"] if row else default

    def set_setting(self, key: str, value: str) -> None:
        with self._lock, self._conn:
            self._conn.execute("INSERT INTO app_settings(key,value) VALUES(?,?) "
                               "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, value))

    def get_interval(self) -> float:
        try:
            return max(1.0, float(self.get_setting("interval_seconds", "5")))
        except ValueError:
            return 5.0

    # ---- detected lots / dedup --------------------------------------
    def is_notified(self, fingerprint: str) -> bool:
        with self._lock:
            row = self._conn.execute("SELECT notified FROM detected_lots WHERE fingerprint=?",
                                     (fingerprint,)).fetchone()
        return bool(row and row["notified"])

    def record_detected(self, fingerprint: str, rule: WatchRule, amount: int, buyout: int,
                        unit_price: float, end_time: str | None) -> None:
        with self._lock, self._conn:
            self._conn.execute(
                "INSERT OR IGNORE INTO detected_lots (fingerprint, rule_id, item_id, item_name, amount,"
                " buyout_price, unit_price, price_limit, end_time, first_seen) VALUES (?,?,?,?,?,?,?,?,?,?)",
                (fingerprint, rule.id, rule.item_id, rule.name, amount, buyout, unit_price,
                 rule.max_unit_price, end_time, _now()))

    def mark_notified(self, fingerprint: str) -> None:
        with self._lock, self._conn:
            self._conn.execute("UPDATE detected_lots SET notified=1 WHERE fingerprint=?", (fingerprint,))

    def count_notified(self) -> int:
        with self._lock:
            return int(self._conn.execute("SELECT COUNT(*) FROM detected_lots WHERE notified=1").fetchone()[0])

    def purge_old(self, days: int = 14) -> None:
        cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()
        with self._lock, self._conn:
            self._conn.execute("DELETE FROM detected_lots WHERE first_seen < ?", (cutoff,))
