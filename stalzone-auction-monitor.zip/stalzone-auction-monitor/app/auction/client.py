"""HTTP client for the official Active Item Lots endpoint.

GET {base}/{region}/auction/{item}/lots     Authorization: Bearer <token>

Rate-limit policy: requests are spaced by MIN_REQUEST_GAP and on HTTP 429 the
client waits for Retry-After. There is no attempt to bypass any limit.
"""
from __future__ import annotations

import asyncio
import logging
import time
from dataclasses import dataclass

import httpx

from ..config import Settings
from .errors import AuctionError, AuthError
from .models import Lot
from .parser import ParseError, parse_lots_response

log = logging.getLogger(__name__)


@dataclass
class LotsResult:
    lots: list[Lot]
    total: int
    truncated: bool = False


class AuctionClient:
    def __init__(self, settings: Settings, http: httpx.AsyncClient | None = None) -> None:
        self._s = settings
        self._http = http or httpx.AsyncClient(
            timeout=settings.request_timeout,
            headers={"Authorization": f"Bearer {settings.api_token}",
                     "Accept": "application/json"},
        )
        self._lock = asyncio.Lock()
        self._last_request = 0.0
        self._blocked_until = 0.0

    async def aclose(self) -> None:
        await self._http.aclose()

    async def _throttle(self) -> None:
        async with self._lock:
            now = time.monotonic()
            wait = max(self._blocked_until - now, self._last_request + self._s.min_request_gap - now)
            if wait > 0:
                await asyncio.sleep(wait)
            self._last_request = time.monotonic()

    async def _get_json(self, url: str, params: dict) -> object:
        last_err: Exception | None = None
        for attempt in range(1, self._s.max_retries + 1):
            await self._throttle()
            try:
                resp = await self._http.get(url, params=params)
            except (httpx.TimeoutException, httpx.TransportError) as exc:
                last_err = exc
                log.warning("Network error (%s), attempt %d/%d", type(exc).__name__,
                            attempt, self._s.max_retries)
                await asyncio.sleep(min(2 ** attempt, 20))
                continue

            code = resp.status_code
            if code == 200:
                try:
                    return resp.json()
                except ValueError as exc:
                    raise AuctionError("response is not valid JSON") from exc
            if code in (401, 403):
                raise AuthError(f"HTTP {code}: check STALZONE_API_TOKEN")
            if code == 404:
                raise AuctionError("HTTP 404: unknown item id or region")
            if code == 429:
                try:
                    delay = float(resp.headers.get("Retry-After", "10"))
                except ValueError:
                    delay = 10.0
                delay = min(max(delay, 1.0), 300.0)
                self._blocked_until = time.monotonic() + delay
                log.warning("Rate limit hit (429), pausing requests for %.0fs", delay)
                last_err = AuctionError("rate limited")
                continue
            if code >= 500:
                last_err = AuctionError(f"HTTP {code}")
                log.warning("Server error %d, attempt %d/%d", code, attempt, self._s.max_retries)
                await asyncio.sleep(min(2 ** attempt, 20))
                continue
            raise AuctionError(f"unexpected HTTP {code}")
        raise AuctionError(f"gave up after {self._s.max_retries} attempts: {last_err}")

    async def fetch_lots(self, item_id: str) -> LotsResult:
        url = f"{self._s.api_base_url}/{self._s.region}/auction/{item_id}/lots"
        lots: list[Lot] = []
        total = 0
        size = self._s.lots_page_size
        for page in range(self._s.max_pages):
            params: dict[str, object] = {"limit": size}
            if page:
                params["offset"] = page * size
            if self._s.lots_sort:
                params["sort"] = self._s.lots_sort
            if self._s.lots_order:
                params["order"] = self._s.lots_order
            payload = await self._get_json(url, params)
            try:
                parsed = parse_lots_response(payload, item_id)
            except ParseError as exc:
                raise AuctionError(str(exc)) from exc
            lots.extend(parsed.lots)
            total = parsed.total
            if len(parsed.lots) + parsed.skipped < size or (page + 1) * size >= total:
                return LotsResult(lots, total)
        log.warning("Item %s: %d lots on market, only %d fetched (raise MAX_PAGES)",
                    item_id, total, len(lots))
        return LotsResult(lots, total, truncated=True)
