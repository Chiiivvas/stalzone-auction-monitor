"""Unit price calculation - the critical business rule."""
from __future__ import annotations

from decimal import Decimal


def unit_price(total_price: int | Decimal, quantity: int) -> Decimal:
    """unit_price = total_price / quantity (exact Decimal, no float rounding)."""
    if isinstance(quantity, bool) or quantity <= 0:
        raise ValueError(f"quantity must be positive, got {quantity!r}")
    if total_price < 0:
        raise ValueError(f"total_price must be non-negative, got {total_price!r}")
    return Decimal(total_price) / Decimal(quantity)
