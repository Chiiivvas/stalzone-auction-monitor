class AuctionError(Exception):
    """Recoverable error: skip this item, try again next cycle."""


class AuthError(AuctionError):
    """401/403: token missing/invalid. Retrying will not help."""
