"""Defensive parser for the Active Item Lots response."""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

from .models import Lot

log = logging.getLogger(__name__)


class ParseError(Exception):
    """The response structure is not what we expect."""


@dataclass
class ParseResult:
    lots: list[Lot] = field(default_factory=list)
    total: int = 0
    skipped: int = 0


def _int(value: Any) -> int | None:
    if isinstance(value, bool) or value is None:
        return None
    if isinstance(value, int):
        return value if value >= 0 else None
    if isinstance(value, float) and value.is_integer() and value >= 0:
        return int(value)
    return None


def _time(value: Any) -> datetime | None:
    if not isinstance(value, str):
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None


def parse_lots_response(payload: Any, requested_item_id: str = "") -> ParseResult:
    if not isinstance(payload, dict) or not isinstance(payload.get("lots"), list):
        raise ParseError("unexpected response: no 'lots' list")
    result = ParseResult(total=_int(payload.get("total")) or len(payload["lots"]))
    for raw in payload["lots"]:
        if not isinstance(raw, dict):
            result.skipped += 1
            continue
        amount = _int(raw.get("amount"))
        start_price = _int(raw.get("startPrice"))
        if amount is None or amount <= 0 or start_price is None:
            log.warning("Skipping malformed lot: %s", str(raw)[:200])
            result.skipped += 1
            continue
        additional = raw.get("additional")
        result.lots.append(Lot(
            item_id=str(raw.get("itemId") or requested_item_id),
            amount=amount,
            start_price=start_price,
            buyout_price=_int(raw.get("buyoutPrice")) or None,  # 0 / missing -> no buyout
            current_price=_int(raw.get("currentPrice")),
            start_time=_time(raw.get("startTime")),
            end_time=_time(raw.get("endTime")),
            additional=additional if isinstance(additional, dict) else {},
        ))
    return result
