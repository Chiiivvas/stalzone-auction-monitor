from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from decimal import Decimal
from typing import Any

from .pricing import unit_price


@dataclass(frozen=True)
class Lot:
    """One active lot from GET /{region}/auction/{item}/lots."""
    item_id: str
    amount: int
    start_price: int
    buyout_price: int | None
    current_price: int | None
    start_time: datetime | None
    end_time: datetime | None
    additional: dict[str, Any] = field(default_factory=dict)
    fingerprint: str = ""  # filled by monitoring.deduplication.assign_fingerprints

    @property
    def unit_price(self) -> Decimal | None:
        """buyoutPrice / amount; None when the lot has no buyout price."""
        if self.buyout_price is None or self.amount <= 0:
            return None
        return unit_price(self.buyout_price, self.amount)


@dataclass
class WatchRule:
    item_id: str                      # API item id, e.g. "g43rp"
    name: str                         # display name chosen by the user
    max_unit_price: int
    min_amount: int = 1
    max_lot_price: int | None = None  # optional cap for the whole lot (buyout)
    enabled: bool = True
    id: int | None = None


@dataclass(frozen=True)
class Match:
    lot: Lot
    rule: WatchRule
    unit_price: Decimal
