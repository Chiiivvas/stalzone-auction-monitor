"""Console + rotating file logs; errors additionally go to a separate file."""
from __future__ import annotations

import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path

FMT = "[%(asctime)s] %(levelname)-5s %(message)s"


def setup_logging(log_dir: str = "logs", level: int = logging.INFO) -> None:
    Path(log_dir).mkdir(parents=True, exist_ok=True)
    root = logging.getLogger()
    root.handlers.clear()
    root.setLevel(level)
    fmt = logging.Formatter(FMT, datefmt="%H:%M:%S")
    file_fmt = logging.Formatter(FMT, datefmt="%Y-%m-%d %H:%M:%S")

    console = logging.StreamHandler()
    console.setFormatter(fmt)
    root.addHandler(console)

    main_file = RotatingFileHandler(Path(log_dir) / "monitor.log", maxBytes=2_000_000,
                                    backupCount=3, encoding="utf-8")
    main_file.setFormatter(file_fmt)
    root.addHandler(main_file)

    err_file = RotatingFileHandler(Path(log_dir) / "errors.log", maxBytes=1_000_000,
                                   backupCount=3, encoding="utf-8")
    err_file.setLevel(logging.WARNING)
    err_file.setFormatter(file_fmt)
    root.addHandler(err_file)

    # httpx logs full request URLs at INFO; the Telegram URL contains the bot token.
    for noisy in ("httpx", "httpcore"):
        logging.getLogger(noisy).setLevel(logging.WARNING)
