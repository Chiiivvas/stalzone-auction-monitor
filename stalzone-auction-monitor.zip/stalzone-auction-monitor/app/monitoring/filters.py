"""Rule matching: all conditions must hold."""
from __future__ import annotations

from decimal import Decimal

from ..auction.models import Lot, Match, WatchRule


def normalize_name(name: str) -> str:
    """Case-fold and collapse whitespace (no fuzzy matching on purpose)."""
    return " ".join(name.split()).casefold()


def evaluate(lot: Lot, rule: WatchRule) -> Match | None:
    if not rule.enabled or lot.item_id != rule.item_id:
        return None
    price = lot.unit_price
    if price is None:                       # no buyout price -> cannot be bought outright
        return None
    if lot.amount < rule.min_amount:
        return None
    if price > Decimal(rule.max_unit_price):  # unit_price <= limit
        return None
    if rule.max_lot_price is not None and lot.buyout_price > rule.max_lot_price:
        return None
    return Match(lot=lot, rule=rule, unit_price=price)


def best_match(lot: Lot, rules: list[WatchRule]) -> Match | None:
    """If several rules match the same lot, use the strictest (lowest) limit."""
    matches = [m for r in rules if (m := evaluate(lot, r))]
    return min(matches, key=lambda m: m.rule.max_unit_price) if matches else None
