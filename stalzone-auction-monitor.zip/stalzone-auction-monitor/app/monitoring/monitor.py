"""Monitoring cycle: fetch -> fingerprint -> match -> dedup -> notify."""
from __future__ import annotations

import asyncio
import logging
import time
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Protocol

from ..auction.errors import AuctionError, AuthError
from ..auction.models import Lot, WatchRule
from ..database.db import Database
from ..notifications.base import (Notification, NotificationError, Notifier,
                                  PermanentNotificationError, money)
from .deduplication import assign_fingerprints
from .filters import best_match

log = logging.getLogger(__name__)


class LotsSource(Protocol):
    async def fetch_lots(self, item_id: str): ...


@dataclass
class MonitorStats:
    status: str = "stopped"          # stopped | running | error
    last_check: datetime | None = None
    last_error: str = ""
    lots_last_cycle: int = 0
    lots_total_seen: int = 0
    matches_total: int = 0
    last_best: str = ""              # "Item — 68 500 ₽/шт."
    last_event: str = ""             # "Item — 78 000 ₽/шт.\nЛот: 5 шт. / 390 000 ₽"
    effective_interval: float = 0.0


class Monitor:
    def __init__(self, db: Database, notifiers: list[Notifier]) -> None:
        self.db = db
        self.notifiers = notifiers
        self.stats = MonitorStats(matches_total=db.count_notified())
        self._dead_notifiers: set[str] = set()

    async def run_cycle(self, source: LotsSource) -> None:
        rules = self.db.list_rules(enabled_only=True)
        by_item: dict[str, list[WatchRule]] = defaultdict(list)
        for r in rules:
            by_item[r.item_id].append(r)

        cycle_lots = 0
        for item_id, item_rules in by_item.items():   # one request per distinct item
            try:
                result = await source.fetch_lots(item_id)
            except AuthError as exc:
                self.stats.status, self.stats.last_error = "error", str(exc)
                log.error("Authorization failed: %s", exc)
                return                                  # no point asking for other items
            except AuctionError as exc:
                self.stats.last_error = f"{item_id}: {exc}"
                log.error("Item %s skipped: %s", item_id, exc)
                continue
            cycle_lots += len(result.lots)
            await self._process_item(result.lots, item_rules)

        self.stats.lots_last_cycle = cycle_lots
        self.stats.lots_total_seen += cycle_lots
        self.stats.last_check = datetime.now()
        if self.stats.status == "error":
            self.stats.status = "running"
        log.info("Auction updated: %d lots, %d items watched", cycle_lots, len(by_item))

    async def _process_item(self, lots: list[Lot], rules: list[WatchRule]) -> None:
        for lot in assign_fingerprints(lots):
            match = best_match(lot, rules)
            if not match:
                continue
            if self.db.is_notified(lot.fingerprint):
                continue                                # already notified about this lot
            unit = match.unit_price
            log.info("Found matching item: %s | lot price %s | qty %d | unit price %s",
                     match.rule.name, lot.buyout_price, lot.amount, money(unit))
            self.db.record_detected(lot.fingerprint, match.rule, lot.amount, lot.buyout_price,
                                    float(unit), lot.end_time.isoformat() if lot.end_time else None)
            note = Notification(
                item_name=match.rule.name, item_id=lot.item_id, amount=lot.amount,
                total_price=lot.buyout_price, unit_price=unit, limit=match.rule.max_unit_price,
                found_at=datetime.now(timezone.utc), end_time=lot.end_time)
            if await self._notify(note):
                self.db.mark_notified(lot.fingerprint)
                self.stats.matches_total = self.db.count_notified()
                self.stats.last_best = f"{match.rule.name} — {money(unit)} ₽/шт."
                self.stats.last_event = (f"{match.rule.name} — {money(unit)} ₽/шт.\n"
                                         f"Лот: {lot.amount} шт. / {money(lot.buyout_price)} ₽")

    async def _notify(self, note: Notification) -> bool:
        """True if at least one notifier delivered. Otherwise retried next cycle."""
        delivered = False
        for n in self.notifiers:
            if n.name in self._dead_notifiers:
                continue
            try:
                await n.send(note)
                delivered = True
                log.info("%s notification sent", n.name.capitalize())
            except PermanentNotificationError as exc:
                self._dead_notifiers.add(n.name)
                self.stats.last_error = str(exc)
                log.error("%s disabled until restart: %s", n.name, exc)
            except NotificationError as exc:
                self.stats.last_error = str(exc)
                log.error("%s notification failed (will retry next cycle): %s", n.name, exc)
            except Exception:
                log.exception("Unexpected error in notifier %s", n.name)
        return delivered

    async def run_forever(self, source: LotsSource, stop: asyncio.Event) -> None:
        self.stats.status = "running"
        log.info("Monitoring started")
        while not stop.is_set():
            started = time.monotonic()
            try:
                await self.run_cycle(source)
                self.db.purge_old()
            except Exception:                         # never die because of one bad cycle
                self.stats.last_error = "unexpected error, see errors.log"
                log.exception("Unexpected error in monitoring cycle")
            interval = self.db.get_interval()
            elapsed = time.monotonic() - started
            self.stats.effective_interval = max(interval, elapsed)
            if elapsed > interval:
                log.warning("Cycle took %.1fs, longer than interval %.0fs (API spacing limits speed)",
                            elapsed, interval)
            try:
                await asyncio.wait_for(stop.wait(), timeout=max(0.0, interval - elapsed))
            except asyncio.TimeoutError:
                pass
        self.stats.status = "stopped"
        log.info("Monitoring stopped")
