"""Lot identity. The API gives no lot id, so we fingerprint immutable fields.

Included: itemId, amount, startPrice, buyoutPrice, startTime, endTime, additional.
Excluded: currentPrice (changes with every bid - would create a "new" lot each bid).
Identical lots in one response get an occurrence suffix (#2, #3...) so they stay distinct.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import replace

from ..auction.models import Lot


def _base(lot: Lot) -> str:
    parts = [
        lot.item_id, lot.amount, lot.start_price, lot.buyout_price,
        lot.start_time.isoformat() if lot.start_time else "",
        lot.end_time.isoformat() if lot.end_time else "",
        json.dumps(lot.additional, sort_keys=True, ensure_ascii=False),
    ]
    return "|".join(str(p) for p in parts)


def fingerprint(lot: Lot, occurrence: int = 1) -> str:
    digest = hashlib.sha256(_base(lot).encode("utf-8")).hexdigest()[:32]
    return digest if occurrence == 1 else f"{digest}#{occurrence}"


def assign_fingerprints(lots: list[Lot]) -> list[Lot]:
    seen: dict[str, int] = {}
    out = []
    for lot in lots:
        base = _base(lot)
        seen[base] = seen.get(base, 0) + 1
        out.append(replace(lot, fingerprint=fingerprint(lot, seen[base])))
    return out
