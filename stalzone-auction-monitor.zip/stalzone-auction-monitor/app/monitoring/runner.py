"""Runs the monitor in a background thread with its own asyncio loop (used by GUI and CLI)."""
from __future__ import annotations

import asyncio
import logging
import threading

from ..auction.client import AuctionClient
from ..config import Settings
from ..notifications.base import Notifier
from ..notifications.telegram import TelegramNotifier
from .monitor import Monitor

log = logging.getLogger(__name__)


def build_notifiers(settings: Settings) -> list[Notifier]:
    notifiers: list[Notifier] = []
    if settings.telegram_token and settings.telegram_chat_id:
        notifiers.append(TelegramNotifier(settings.telegram_token, settings.telegram_chat_id,
                                          retries=settings.max_retries,
                                          timeout=settings.request_timeout))
    else:
        log.warning("Telegram is not configured (TELEGRAM_BOT_TOKEN / TELEGRAM_CHAT_ID)")
    return notifiers


class MonitorRunner:
    def __init__(self, settings: Settings, monitor: Monitor) -> None:
        self.settings = settings
        self.monitor = monitor
        self._thread: threading.Thread | None = None
        self._loop: asyncio.AbstractEventLoop | None = None
        self._stop: asyncio.Event | None = None

    @property
    def running(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    def start(self) -> None:
        if self.running:
            return
        self._thread = threading.Thread(target=lambda: asyncio.run(self._main()),
                                        name="monitor", daemon=True)
        self._thread.start()

    def stop(self, timeout: float = 5.0) -> None:
        if self._loop and self._stop:
            self._loop.call_soon_threadsafe(self._stop.set)
        if self._thread:
            self._thread.join(timeout)

    async def _main(self) -> None:
        self._loop = asyncio.get_running_loop()
        self._stop = asyncio.Event()
        client = AuctionClient(self.settings)
        try:
            await self.monitor.run_forever(client, self._stop)
        finally:
            await client.aclose()
            for n in self.monitor.notifiers:
                close = getattr(n, "aclose", None)
                if close:
                    await close()
