from __future__ import annotations

import asyncio
import logging

import httpx

from .base import (NotificationError, Notification, Notifier,
                   PermanentNotificationError, format_message)

log = logging.getLogger(__name__)


class TelegramNotifier(Notifier):
    name = "telegram"

    def __init__(self, token: str, chat_id: str, retries: int = 3, timeout: float = 10.0,
                 http: httpx.AsyncClient | None = None) -> None:
        self._url = f"https://api.telegram.org/bot{token}/sendMessage"  # never logged
        self._chat_id = chat_id
        self._retries = retries
        self._http = http or httpx.AsyncClient(timeout=timeout)

    async def send(self, notification: Notification) -> None:
        body = {"chat_id": self._chat_id, "text": format_message(notification),
                "disable_web_page_preview": True}
        last = "unknown error"
        for attempt in range(1, self._retries + 1):
            try:
                resp = await self._http.post(self._url, json=body)
            except httpx.HTTPError as exc:   # message may contain the URL -> log type only
                last = type(exc).__name__
                await asyncio.sleep(min(2 ** attempt, 15))
                continue
            if resp.status_code == 200:
                return
            if resp.status_code in (400, 401, 403, 404):
                raise PermanentNotificationError(
                    f"Telegram HTTP {resp.status_code}: check TELEGRAM_BOT_TOKEN / TELEGRAM_CHAT_ID "
                    "(write /start to the bot first)")
            if resp.status_code == 429:
                try:
                    delay = float(resp.json()["parameters"]["retry_after"])
                except (ValueError, KeyError, TypeError):
                    delay = 5.0
                last = "rate limited"
                await asyncio.sleep(min(delay, 60))
                continue
            last = f"HTTP {resp.status_code}"
            await asyncio.sleep(min(2 ** attempt, 15))
        raise NotificationError(f"Telegram failed after {self._retries} attempts: {last}")

    async def aclose(self) -> None:
        await self._http.aclose()
