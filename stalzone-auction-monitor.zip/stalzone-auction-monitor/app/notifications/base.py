"""Notifier abstraction. Add Discord/desktop/email by subclassing Notifier."""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal


class NotificationError(Exception):
    """Sending failed (maybe temporarily)."""


class PermanentNotificationError(NotificationError):
    """Misconfiguration (bad token / chat id). Do not keep retrying."""


@dataclass(frozen=True)
class Notification:
    item_name: str
    item_id: str
    amount: int
    total_price: int
    unit_price: Decimal
    limit: int
    found_at: datetime
    end_time: datetime | None = None


def money(value: int | Decimal) -> str:
    d = Decimal(value)
    if d == d.to_integral_value():
        return f"{int(d):,}".replace(",", " ")
    return f"{d:,.2f}".replace(",", " ")


def format_message(n: Notification) -> str:
    lines = [
        "🚨 Найден выгодный лот!",
        "",
        f"Предмет: {n.item_name}",
        f"Количество: {n.amount} шт.",
        f"Общая цена: {money(n.total_price)} ₽",
        f"Цена за 1 шт.: {money(n.unit_price)} ₽",
        f"Ваш лимит: {money(n.limit)} ₽",
        "",
        f"Экономия: {money(Decimal(n.limit) - n.unit_price)} ₽ / шт.",
        "",
        f"ID предмета: {n.item_id}",
    ]
    if n.end_time:
        lines.append(f"Лот истекает: {n.end_time.astimezone().strftime('%d.%m.%Y %H:%M')}")
    lines.append(f"Лот найден: {n.found_at.astimezone().strftime('%d.%m.%Y %H:%M:%S')}")
    return "\n".join(lines)


class Notifier(ABC):
    name = "notifier"

    @abstractmethod
    async def send(self, notification: Notification) -> None:
        """Raise NotificationError on failure."""
