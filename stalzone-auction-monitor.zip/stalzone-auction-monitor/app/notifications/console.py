import logging

from .base import Notification, Notifier, format_message

log = logging.getLogger(__name__)


class ConsoleNotifier(Notifier):
    """Fallback/debug notifier: writes the alert to the log."""
    name = "console"

    async def send(self, notification: Notification) -> None:
        log.info("ALERT\n%s", format_message(notification))
