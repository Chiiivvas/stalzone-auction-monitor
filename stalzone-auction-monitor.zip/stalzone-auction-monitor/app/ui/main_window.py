"""Tkinter GUI (stdlib, no extra dependencies)."""
from __future__ import annotations

import tkinter as tk
from tkinter import messagebox, ttk

from ..auction.models import WatchRule
from ..config import Settings
from ..database.db import Database
from ..monitoring.monitor import Monitor
from ..monitoring.runner import MonitorRunner
from ..notifications.base import money

INTERVALS = [1, 3, 5, 10, 30, 60]


def _parse_int(text: str, field: str, minimum: int = 0, optional: bool = False) -> int | None:
    cleaned = text.replace(" ", "").replace("\u00a0", "").replace("_", "")
    if not cleaned:
        if optional:
            return None
        raise ValueError(f"Поле «{field}» обязательно")
    if not cleaned.isdigit() or int(cleaned) < minimum:
        raise ValueError(f"Поле «{field}»: нужно целое число ≥ {minimum}")
    return int(cleaned)


class RuleDialog(tk.Toplevel):
    def __init__(self, parent: tk.Misc, rule: WatchRule | None = None) -> None:
        super().__init__(parent)
        self.title("Предмет" if rule else "Новый предмет")
        self.resizable(False, False)
        self.result: WatchRule | None = None
        self._id = rule.id if rule else None
        self.vars = {
            "name": tk.StringVar(value=rule.name if rule else ""),
            "item_id": tk.StringVar(value=rule.item_id if rule else ""),
            "price": tk.StringVar(value=str(rule.max_unit_price) if rule else ""),
            "min_amount": tk.StringVar(value=str(rule.min_amount) if rule else "1"),
            "max_lot": tk.StringVar(value=str(rule.max_lot_price or "") if rule else ""),
        }
        self.enabled = tk.BooleanVar(value=rule.enabled if rule else True)
        rows = [("Название", "name"), ("ID предмета (API)", "item_id"),
                ("Макс. цена за 1 шт., ₽", "price"), ("Мин. количество в лоте", "min_amount"),
                ("Макс. цена всего лота, ₽ (необяз.)", "max_lot")]
        for i, (label, key) in enumerate(rows):
            ttk.Label(self, text=label).grid(row=i, column=0, sticky="w", padx=8, pady=4)
            ttk.Entry(self, textvariable=self.vars[key], width=32).grid(row=i, column=1, padx=8, pady=4)
        ttk.Checkbutton(self, text="Мониторинг включён", variable=self.enabled).grid(
            row=len(rows), column=0, columnspan=2, sticky="w", padx=8)
        btns = ttk.Frame(self)
        btns.grid(row=len(rows) + 1, column=0, columnspan=2, pady=8)
        ttk.Button(btns, text="Сохранить", command=self._save).pack(side="left", padx=4)
        ttk.Button(btns, text="Отмена", command=self.destroy).pack(side="left", padx=4)
        self.transient(parent)
        self.grab_set()

    def _save(self) -> None:
        try:
            name = self.vars["name"].get().strip()
            item_id = self.vars["item_id"].get().strip()
            if not name or not item_id:
                raise ValueError("Укажите название и ID предмета")
            self.result = WatchRule(
                id=self._id, name=name, item_id=item_id,
                max_unit_price=_parse_int(self.vars["price"].get(), "Макс. цена за 1 шт.", 0),
                min_amount=_parse_int(self.vars["min_amount"].get(), "Мин. количество", 1),
                max_lot_price=_parse_int(self.vars["max_lot"].get(), "Макс. цена лота", 0, optional=True),
                enabled=self.enabled.get())
        except ValueError as exc:
            messagebox.showerror("Ошибка", str(exc), parent=self)
            return
        self.destroy()


class App(ttk.Frame):
    def __init__(self, root: tk.Tk, settings: Settings, db: Database,
                 monitor: Monitor, runner: MonitorRunner) -> None:
        super().__init__(root, padding=10)
        self.root, self.settings, self.db, self.monitor, self.runner = root, settings, db, monitor, runner
        self.pack(fill="both", expand=True)

        ttk.Label(self, text="STALZONE Auction Monitor", font=("", 14, "bold")).pack()
        self.status = ttk.Label(self, text="")
        self.status.pack(anchor="w", pady=(8, 0))
        self.info = ttk.Label(self, text="", justify="left")
        self.info.pack(anchor="w")

        bar = ttk.Frame(self)
        bar.pack(fill="x", pady=6)
        self.toggle_btn = ttk.Button(bar, text="▶ Запустить", command=self._toggle)
        self.toggle_btn.pack(side="left")
        ttk.Label(bar, text="  Интервал, сек:").pack(side="left")
        self.interval = ttk.Combobox(bar, values=INTERVALS, width=5, state="readonly")
        current = int(db.get_interval())
        self.interval.set(current if current in INTERVALS else 5)
        self.interval.pack(side="left")
        self.interval.bind("<<ComboboxSelected>>", self._interval_changed)

        cols = ("name", "limit", "min", "status")
        self.tree = ttk.Treeview(self, columns=cols, show="headings", height=10)
        for c, t, w in (("name", "Предмет", 220), ("limit", "Лимит, ₽/шт.", 110),
                        ("min", "Мин. кол-во", 90), ("status", "Статус", 70)):
            self.tree.heading(c, text=t)
            self.tree.column(c, width=w, anchor="w" if c == "name" else "center")
        self.tree.pack(fill="both", expand=True)
        self.tree.bind("<Double-1>", lambda _e: self._edit())

        actions = ttk.Frame(self)
        actions.pack(fill="x", pady=6)
        for text, cmd in (("+ Добавить предмет", self._add), ("Изменить", self._edit),
                          ("Вкл/выкл", self._toggle_rule), ("Удалить", self._delete)):
            ttk.Button(actions, text=text, command=cmd).pack(side="left", padx=2)

        ttk.Separator(self).pack(fill="x", pady=4)
        ttk.Label(self, text="Последнее событие:").pack(anchor="w")
        self.event = ttk.Label(self, text="—", justify="left")
        self.event.pack(anchor="w")

        self._reload()
        self._tick()

    # ---- rules -------------------------------------------------------
    def _reload(self) -> None:
        self.tree.delete(*self.tree.get_children())
        for r in self.db.list_rules():
            self.tree.insert("", "end", iid=str(r.id), values=(
                r.name, money(r.max_unit_price), r.min_amount, "🟢" if r.enabled else "🔴"))

    def _selected(self) -> WatchRule | None:
        sel = self.tree.selection()
        if not sel:
            messagebox.showinfo("Выбор", "Сначала выберите предмет в списке")
            return None
        return next((r for r in self.db.list_rules() if r.id == int(sel[0])), None)

    def _add(self) -> None:
        dlg = RuleDialog(self.root)
        self.root.wait_window(dlg)
        if dlg.result:
            self.db.add_rule(dlg.result)
            self._reload()

    def _edit(self) -> None:
        rule = self._selected()
        if not rule:
            return
        dlg = RuleDialog(self.root, rule)
        self.root.wait_window(dlg)
        if dlg.result:
            self.db.update_rule(dlg.result)
            self._reload()

    def _toggle_rule(self) -> None:
        rule = self._selected()
        if rule:
            rule.enabled = not rule.enabled
            self.db.update_rule(rule)
            self._reload()

    def _delete(self) -> None:
        rule = self._selected()
        if rule and messagebox.askyesno("Удаление", f"Удалить «{rule.name}»?"):
            self.db.delete_rule(rule.id)
            self._reload()

    # ---- monitor control --------------------------------------------
    def _toggle(self) -> None:
        if self.runner.running:
            self.runner.stop()
        else:
            if not self.settings.api_token:
                messagebox.showerror("Нет токена", "Укажите STALZONE_API_TOKEN в файле .env")
                return
            self.runner.start()

    def _interval_changed(self, _e=None) -> None:
        self.db.set_setting("interval_seconds", self.interval.get())

    def _tick(self) -> None:
        s = self.monitor.stats
        running = self.runner.running
        icon = {"running": "🟢 Мониторинг работает", "error": "🟠 Ошибка (см. лог)"}.get(
            s.status if running else "stopped", "⚪ Остановлен")
        self.status.config(text=icon)
        self.toggle_btn.config(text="■ Остановить" if running else "▶ Запустить")
        last = s.last_check.strftime("%H:%M:%S") if s.last_check else "—"
        eff = f" (фактически ~{s.effective_interval:.1f} с)" if s.effective_interval > float(self.interval.get()) else ""
        self.info.config(text=(
            f"Регион: {self.settings.region.upper()}\n"
            f"Последняя проверка: {last}\n"
            f"Отслеживаемых предметов: {len(self.db.list_rules(enabled_only=True))}\n"
            f"Лотов в последней проверке: {s.lots_last_cycle}\n"
            f"Подходящих предложений: {s.matches_total}\n"
            f"Последняя найденная выгодная цена: {s.last_best or '—'}{eff}"
            + (f"\nПоследняя ошибка: {s.last_error}" if s.last_error else "")))
        self.event.config(text=s.last_event or "—")
        self.root.after(1000, self._tick)


def run_gui(settings: Settings, db: Database, monitor: Monitor, runner: MonitorRunner) -> None:
    root = tk.Tk()
    root.title("STALZONE Auction Monitor RU")
    root.geometry("620x620")
    App(root, settings, db, monitor, runner)

    def on_close() -> None:
        runner.stop()
        root.destroy()

    root.protocol("WM_DELETE_WINDOW", on_close)
    root.mainloop()
