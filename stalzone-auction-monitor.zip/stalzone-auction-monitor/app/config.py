"""Configuration loaded from environment / .env (no secrets in source code)."""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path


def load_env_file(path: str | Path = ".env") -> None:
    """Tiny .env loader: KEY=VALUE lines, '#' comments. Real env vars win."""
    p = Path(path)
    if not p.is_file():
        return
    for raw in p.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        value = value.strip().strip('"').strip("'")
        os.environ.setdefault(key.strip(), value)


def _f(name: str, default: float) -> float:
    try:
        return float(os.getenv(name, "") or default)
    except ValueError:
        return default


def _i(name: str, default: int) -> int:
    try:
        return int(os.getenv(name, "") or default)
    except ValueError:
        return default


@dataclass(frozen=True)
class Settings:
    api_token: str
    api_base_url: str
    region: str
    lots_sort: str
    lots_order: str
    telegram_token: str
    telegram_chat_id: str
    db_path: str
    log_dir: str
    request_timeout: float
    min_request_gap: float
    max_retries: int
    lots_page_size: int
    max_pages: int


def load_settings() -> Settings:
    load_env_file()
    return Settings(
        api_token=os.getenv("STALZONE_API_TOKEN", "").strip(),
        api_base_url=(os.getenv("STALZONE_API_BASE_URL") or "https://eapi.stalzone.com").rstrip("/"),
        region=(os.getenv("STALZONE_REGION") or "ru").strip().lower(),
        lots_sort=os.getenv("LOTS_SORT", "").strip(),
        lots_order=os.getenv("LOTS_ORDER", "").strip(),
        telegram_token=os.getenv("TELEGRAM_BOT_TOKEN", "").strip(),
        telegram_chat_id=os.getenv("TELEGRAM_CHAT_ID", "").strip(),
        db_path=os.getenv("DB_PATH") or "data/monitor.db",
        log_dir=os.getenv("LOG_DIR") or "logs",
        request_timeout=_f("REQUEST_TIMEOUT", 10.0),
        min_request_gap=_f("MIN_REQUEST_GAP", 0.25),
        max_retries=max(1, _i("MAX_RETRIES", 3)),
        lots_page_size=min(200, max(1, _i("LOTS_PAGE_SIZE", 200))),
        max_pages=max(1, _i("MAX_PAGES", 2)),
    )
