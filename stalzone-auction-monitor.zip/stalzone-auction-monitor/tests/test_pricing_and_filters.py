import unittest
from decimal import Decimal

from app.auction.models import Lot, WatchRule
from app.auction.pricing import unit_price
from app.monitoring.filters import best_match, evaluate, normalize_name


def mk(amount, buyout, item="x", cur=None):
    return Lot(item_id=item, amount=amount, start_price=1, buyout_price=buyout,
               current_price=cur, start_time=None, end_time=None)


class UnitPrice(unittest.TestCase):
    def test_spec_cases(self):
        cases = [(100_000, 1, 100_000), (400_000, 5, 80_000), (5_000_000, 100, 50_000),
                 (7_000_000, 100, 70_000), (700_000, 10, 70_000), (1_600_000, 20, 80_000)]
        for total, qty, expected in cases:
            self.assertEqual(unit_price(total, qty), Decimal(expected))

    def test_fractional_from_api_example(self):
        self.assertAlmostEqual(float(unit_price(19_000_000, 3)), 6_333_333.33, places=2)

    def test_invalid(self):
        for qty in (0, -1):
            with self.assertRaises(ValueError):
                unit_price(100, qty)


class Matching(unittest.TestCase):
    rule = WatchRule(item_id="x", name="X", max_unit_price=75_000, id=1)

    def test_multi_item_lot_matches(self):      # 700k/10 = 70k <= 75k
        self.assertIsNotNone(evaluate(mk(10, 700_000), self.rule))

    def test_multi_item_lot_too_expensive(self):  # 1.6M/20 = 80k > 75k
        self.assertIsNone(evaluate(mk(20, 1_600_000), self.rule))

    def test_limit_is_inclusive(self):
        self.assertIsNotNone(evaluate(mk(4, 300_000), self.rule))

    def test_spec_limit_60k(self):
        r = WatchRule(item_id="x", name="X", max_unit_price=60_000)
        self.assertIsNotNone(evaluate(mk(100, 5_000_000), r))
        self.assertIsNone(evaluate(mk(100, 7_000_000), r))

    def test_no_buyout_never_matches(self):
        self.assertIsNone(evaluate(mk(1, None, cur=100), self.rule))

    def test_min_amount(self):
        r = WatchRule(item_id="x", name="X", max_unit_price=100_000, min_amount=5)
        self.assertIsNone(evaluate(mk(4, 100_000), r))
        self.assertIsNotNone(evaluate(mk(5, 100_000), r))

    def test_max_lot_price(self):
        r = WatchRule(item_id="x", name="X", max_unit_price=100_000, max_lot_price=1_000_000)
        self.assertIsNone(evaluate(mk(20, 1_200_000), r))
        self.assertIsNotNone(evaluate(mk(10, 900_000), r))

    def test_disabled_and_other_item(self):
        r = WatchRule(item_id="x", name="X", max_unit_price=10**9, enabled=False)
        self.assertIsNone(evaluate(mk(1, 1), r))
        self.assertIsNone(evaluate(mk(1, 1, item="y"), self.rule))

    def test_strictest_rule_wins(self):
        a = WatchRule(item_id="x", name="A", max_unit_price=90_000)
        b = WatchRule(item_id="x", name="B", max_unit_price=80_000)
        self.assertEqual(best_match(mk(1, 70_000), [a, b]).rule.name, "B")

    def test_normalize_name(self):
        self.assertEqual(normalize_name("  МЕДИКАМЕНТЫ  "), normalize_name("медикаменты"))
        self.assertEqual(normalize_name("a   b"), "a b")


if __name__ == "__main__":
    unittest.main()
