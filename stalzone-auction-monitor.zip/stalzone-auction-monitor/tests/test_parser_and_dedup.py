import unittest

from app.auction.parser import ParseError, parse_lots_response
from app.monitoring.deduplication import assign_fingerprints

SAMPLE = {"total": 4, "lots": [
    {"itemId": "g43rp", "amount": 1, "startPrice": 17000000, "buyoutPrice": 17500000,
     "startTime": "2024-01-07T15:47:54Z", "endTime": "2024-01-07T21:47:54Z", "additional": {}},
    {"itemId": "g43rp", "amount": 3, "startPrice": 9000000, "currentPrice": 15000000,
     "buyoutPrice": 19000000, "startTime": "2024-01-05T21:51:12Z",
     "endTime": "2024-01-07T21:51:12Z", "additional": {}}]}


class Parser(unittest.TestCase):
    def test_api_sample(self):
        r = parse_lots_response(SAMPLE, "g43rp")
        self.assertEqual(len(r.lots), 2)
        self.assertEqual(r.lots[1].amount, 3)
        self.assertAlmostEqual(float(r.lots[1].unit_price), 6_333_333.33, places=2)
        self.assertIsNone(r.lots[0].current_price)

    def test_missing_buyout(self):
        r = parse_lots_response({"lots": [{"amount": 2, "startPrice": 10}]}, "a")
        self.assertIsNone(r.lots[0].buyout_price)
        self.assertIsNone(r.lots[0].unit_price)

    def test_bad_lots_are_skipped(self):
        r = parse_lots_response({"lots": [{"amount": 0, "startPrice": 1}, "x",
                                          {"amount": "5", "startPrice": 1},
                                          {"amount": 1, "startPrice": 1, "buyoutPrice": 5}]}, "a")
        self.assertEqual((len(r.lots), r.skipped), (1, 3))

    def test_bad_structure(self):
        for bad in (None, [], {}, {"lots": "no"}):
            with self.assertRaises(ParseError):
                parse_lots_response(bad)

    def test_empty(self):
        self.assertEqual(parse_lots_response({"total": 0, "lots": []}).lots, [])


class Fingerprint(unittest.TestCase):
    def lots(self, cur=None):
        d = dict(SAMPLE["lots"][1]); d["currentPrice"] = cur
        return parse_lots_response({"lots": [d]}).lots

    def test_stable_and_ignores_bids(self):
        a = assign_fingerprints(self.lots(15_000_000))[0].fingerprint
        b = assign_fingerprints(self.lots(16_000_000))[0].fingerprint
        self.assertEqual(a, b)

    def test_different_lots_differ(self):
        l = assign_fingerprints(parse_lots_response(SAMPLE).lots)
        self.assertNotEqual(l[0].fingerprint, l[1].fingerprint)

    def test_identical_lots_stay_distinct(self):
        one = SAMPLE["lots"][0]
        l = assign_fingerprints(parse_lots_response({"lots": [one, one]}).lots)
        self.assertNotEqual(l[0].fingerprint, l[1].fingerprint)


if __name__ == "__main__":
    unittest.main()
