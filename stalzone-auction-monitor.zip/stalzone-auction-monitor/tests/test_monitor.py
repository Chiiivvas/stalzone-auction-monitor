import asyncio
import unittest

from app.auction.errors import AuctionError, AuthError
from app.auction.models import WatchRule
from app.auction.parser import parse_lots_response
from app.database.db import Database
from app.monitoring.monitor import Monitor
from app.notifications.base import NotificationError, Notifier, PermanentNotificationError


class FakeResult:
    def __init__(self, lots): self.lots = lots


class FakeSource:
    def __init__(self): self.lots_by_item = {}; self.error = None; self.calls = []
    async def fetch_lots(self, item_id):
        self.calls.append(item_id)
        if self.error: raise self.error
        return FakeResult(self.lots_by_item.get(item_id, []))


class FakeNotifier(Notifier):
    name = "fake"
    def __init__(self): self.sent = []; self.fail = None
    async def send(self, n):
        if self.fail: raise self.fail
        self.sent.append(n)


def lot(item, amount, buyout, start="2026-10-06T10:00:00Z"):
    return parse_lots_response({"lots": [{"itemId": item, "amount": amount, "startPrice": 1,
        "buyoutPrice": buyout, "startTime": start, "endTime": "2026-10-07T10:00:00Z"}]}).lots[0]


class MonitorTests(unittest.TestCase):
    def setUp(self):
        self.db = Database(":memory:")
        self.db.add_rule(WatchRule(item_id="x", name="X", max_unit_price=75_000))
        self.db.add_rule(WatchRule(item_id="x", name="X strict", max_unit_price=60_000))
        self.src, self.nt = FakeSource(), FakeNotifier()
        self.mon = Monitor(self.db, [self.nt])

    def cycle(self): asyncio.run(self.mon.run_cycle(self.src))

    def test_notifies_once_for_same_lot(self):
        self.src.lots_by_item["x"] = [lot("x", 10, 700_000)]
        for _ in range(3): self.cycle()
        self.assertEqual(len(self.nt.sent), 1)
        self.assertEqual(self.nt.sent[0].unit_price, 70_000)
        self.assertEqual(self.mon.stats.matches_total, 1)

    def test_one_request_per_item_even_with_two_rules(self):
        self.src.lots_by_item["x"] = []
        self.cycle()
        self.assertEqual(self.src.calls, ["x"])

    def test_new_lot_after_old_disappears(self):
        self.src.lots_by_item["x"] = [lot("x", 10, 700_000)]
        self.cycle()
        self.src.lots_by_item["x"] = []
        self.cycle()
        self.src.lots_by_item["x"] = [lot("x", 10, 700_000, start="2026-10-06T11:00:00Z")]
        self.cycle()
        self.assertEqual(len(self.nt.sent), 2)

    def test_too_expensive_not_notified(self):
        self.src.lots_by_item["x"] = [lot("x", 20, 1_600_000)]
        self.cycle()
        self.assertEqual(self.nt.sent, [])

    def test_failed_delivery_is_retried(self):
        self.src.lots_by_item["x"] = [lot("x", 1, 50_000)]
        self.nt.fail = NotificationError("down")
        self.cycle()
        self.assertEqual(self.mon.stats.matches_total, 0)
        self.nt.fail = None
        self.cycle()
        self.assertEqual(len(self.nt.sent), 1)

    def test_permanent_notifier_error_disables_it(self):
        self.src.lots_by_item["x"] = [lot("x", 1, 50_000)]
        self.nt.fail = PermanentNotificationError("bad token")
        self.cycle(); self.nt.fail = None; self.cycle()
        self.assertEqual(self.nt.sent, [])

    def test_api_errors_do_not_crash(self):
        self.src.error = AuctionError("boom")
        self.cycle()
        self.src.error = AuthError("401")
        self.cycle()
        self.assertEqual(self.mon.stats.status, "error")

    def test_raised_limit_triggers_old_lot(self):
        self.src.lots_by_item["x"] = [lot("x", 1, 90_000)]
        self.cycle()
        self.assertEqual(self.nt.sent, [])
        for r in self.db.list_rules():
            r.max_unit_price = 100_000; self.db.update_rule(r)
        self.cycle()
        self.assertEqual(len(self.nt.sent), 1)


class DbTests(unittest.TestCase):
    def test_rules_crud_and_interval(self):
        db = Database(":memory:")
        rid = db.add_rule(WatchRule(item_id="a", name="A", max_unit_price=5, min_amount=2, max_lot_price=99))
        r = db.list_rules()[0]
        self.assertEqual((r.id, r.min_amount, r.max_lot_price), (rid, 2, 99))
        r.enabled = False; db.update_rule(r)
        self.assertEqual(db.list_rules(enabled_only=True), [])
        db.delete_rule(rid); self.assertEqual(db.list_rules(), [])
        self.assertEqual(db.get_interval(), 5.0)
        db.set_setting("interval_seconds", "30"); self.assertEqual(db.get_interval(), 30.0)


if __name__ == "__main__":
    unittest.main()
