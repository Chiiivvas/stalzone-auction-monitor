"""Needs httpx (pip install -r requirements.txt); skipped otherwise."""
import asyncio
import unittest
from dataclasses import replace

try:
    import httpx
except ImportError:  # pragma: no cover
    httpx = None


@unittest.skipIf(httpx is None, "httpx not installed")
class ClientTests(unittest.TestCase):
    def settings(self, **kw):
        from app.config import Settings
        base = Settings("tok", "https://eapi.stalzone.com", "ru", "", "", "", "", ":memory:", "logs",
                        5, 0.0, 3, 200, 2)
        return replace(base, **kw)

    def run_client(self, handler, **kw):
        from app.auction.client import AuctionClient
        http = httpx.AsyncClient(transport=httpx.MockTransport(handler),
                                 headers={"Authorization": "Bearer tok"})
        async def go():
            c = AuctionClient(self.settings(**kw), http)
            return await c.fetch_lots("g43rp")
        return asyncio.run(go())

    def test_url_and_success(self):
        seen = {}
        def h(req):
            seen["url"] = str(req.url)
            return httpx.Response(200, json={"total": 1, "lots": [
                {"itemId": "g43rp", "amount": 3, "startPrice": 1, "buyoutPrice": 19000000}]})
        res = self.run_client(h)
        self.assertTrue(seen["url"].startswith("https://eapi.stalzone.com/ru/auction/g43rp/lots"))
        self.assertEqual(len(res.lots), 1)

    def test_auth_error(self):
        from app.auction.errors import AuthError
        with self.assertRaises(AuthError):
            self.run_client(lambda r: httpx.Response(401))

    def test_retries_server_error_then_succeeds(self):
        import app.auction.client as c
        calls = {"n": 0}
        def h(req):
            calls["n"] += 1
            return httpx.Response(503) if calls["n"] < 2 else httpx.Response(200, json={"lots": []})
        orig, c.asyncio.sleep = c.asyncio.sleep, (lambda s: orig(0))
        try:
            self.assertEqual(self.run_client(h).lots, [])
        finally:
            c.asyncio.sleep = orig
        self.assertEqual(calls["n"], 2)

    def test_changed_structure_is_error(self):
        from app.auction.errors import AuctionError
        with self.assertRaises(AuctionError):
            self.run_client(lambda r: httpx.Response(200, json={"oops": 1}))


if __name__ == "__main__":
    unittest.main()
